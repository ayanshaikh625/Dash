# NodeNest — Anime Node Host Panel

A lightweight Node.js hosting dashboard. It creates isolated **process-based Node server containers** under `data/servers`, and every server is launched with the exact same Node executable as the panel (`process.execPath`).

## Features
- Create / start / stop / restart / delete Node servers
- Per-server filesystem
- File browser and uploads up to 100 MB
- Basic in-panel file editor
- Live WebSocket console and stdin command input
- Per-server Node heap setting
- Host Node version/runtime display
- Cute anime-inspired UI with no external character assets required

## Important
This is **not Docker**. The servers are separate child processes with separate working directories. They share the host OS permissions and Node runtime. Do not expose the panel publicly without adding HTTPS, a reverse proxy, and stronger authentication.

## Install
```bash
npm install
```

Set a strong panel password:
```bash
# Linux/macOS
export PANEL_PASSWORD='your-strong-password'
export PORT=3000
# The panel is hard-locked to port 3000.
npm start
```

Windows PowerShell:
```powershell
$env:PANEL_PASSWORD='your-strong-password'
$env:PORT='3000'  # panel remains locked to 3000
npm start
```

Open `http://YOUR_HOST:3000`.

## Server layout
`data/servers/<server-id>/` is that server's working directory. Its entry file defaults to `index.js`.

## Security
The panel can start arbitrary Node.js code stored in its server directories and can send stdin to running processes. Treat it as an admin panel. Keep it private or place it behind a trusted proxy/VPN.

'use strict';
require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const { spawn } = require('child_process');
const multer = require('multer');
const { WebSocketServer } = require('ws');

const app = express();
const server = http.createServer(app);
const PORT = 3000; // Fixed panel port: do not use host PORT/8080
const HOST = process.env.HOST || '0.0.0.0';
const PASSWORD = String(process.env.PANEL_PASSWORD ?? 'change-me-now').trim();
const ROOT = path.join(__dirname, 'data', 'servers');
const META = path.join(__dirname, 'data', 'servers.json');
const NODE = process.execPath;
const sessions = new Map();
const processes = new Map();
const logs = new Map();

fs.mkdirSync(ROOT, { recursive: true });
if (!fs.existsSync(META)) fs.writeFileSync(META, '{}');
function readMeta(){ try{return JSON.parse(fs.readFileSync(META,'utf8'));}catch{return {};}}
function writeMeta(m){fs.writeFileSync(META,JSON.stringify(m,null,2));}
function idSafe(v){return /^[a-zA-Z0-9_-]{1,32}$/.test(v);}
function safePath(base, rel=''){const b=path.resolve(base), p=path.resolve(base, rel); if(p!==b && !p.startsWith(b+path.sep)) throw new Error('Invalid path'); return p;}
function token(){return crypto.randomBytes(32).toString('hex');}
function auth(req,res,next){const t=req.headers.authorization?.replace('Bearer ','') || req.query.token; if(!t || !sessions.has(t)) return res.status(401).json({error:'Unauthorized'}); next();}
function addLog(id,text){const line=String(text).replace(/\r/g,''); const arr=logs.get(id)||[]; arr.push(line); if(arr.length>500) arr.splice(0,arr.length-500); logs.set(id,arr); broadcast(id,{type:'log',data:line});}
function broadcast(id,obj){const s=processes.get(id); if(!s?.clients)return; const raw=JSON.stringify(obj); for(const ws of s.clients){if(ws.readyState===1)ws.send(raw);}}
function info(id){const m=readMeta()[id]; const p=processes.get(id); return {...m,id,status:p?.child&&!p.child.killed?'online':'offline',pid:p?.child?.pid||null,node:NODE,logs:(logs.get(id)||[]).slice(-100)};}
function start(id){const meta=readMeta(); const m=meta[id]; if(!m) throw new Error('Server not found'); if(processes.get(id)?.child&&!processes.get(id).child.killed) return;
  const dir=path.join(ROOT,id); fs.mkdirSync(dir,{recursive:true});
  const entry=m.entry||'index.js'; const entryPath=safePath(dir,entry); if(!fs.existsSync(entryPath)) throw new Error(`Entry file not found: ${entry}`);
  const args=[]; if(m.maxMemory) args.push(`--max-old-space-size=${Math.max(128,Number(m.maxMemory))}`); args.push(entry);
  const child=spawn(NODE,args,{cwd:dir,env:{...process.env,NODE_ENV:'production'},stdio:['pipe','pipe','pipe'],windowsHide:true});
  const state={child,clients:new Set(),startedAt:Date.now()}; processes.set(id,state);
  addLog(id,`[Panel] Started ${m.name} using ${NODE} (PID ${child.pid})`);
  child.stdout.on('data',d=>addLog(id,d.toString())); child.stderr.on('data',d=>addLog(id,d.toString()));
  child.on('exit',(code,sig)=>{addLog(id,`[Panel] Process exited code=${code} signal=${sig||'none'}`); broadcast(id,{type:'status',status:'offline'}); processes.delete(id);});
  child.on('error',e=>addLog(id,`[Panel] Process error: ${e.message}`));
}
function stop(id){const p=processes.get(id); if(!p?.child)return; p.child.kill('SIGTERM'); setTimeout(()=>{if(processes.get(id)?.child===p.child&&!p.child.killed)p.child.kill('SIGKILL');},5000);}
app.use(express.json({limit:'2mb'})); app.use(express.static(path.join(__dirname,'public')));
app.post('/api/login',(req,res)=>{const supplied=String(req.body?.password ?? '').trim();if(!supplied || supplied!==PASSWORD)return res.status(403).json({error:'Wrong password'});const t=token();sessions.set(t,Date.now());res.json({token:t});});
app.get('/api/me',auth,(req,res)=>res.json({node:NODE,platform:process.platform,nodeVersion:process.version}));
app.get('/api/servers',auth,(req,res)=>{const m=readMeta();res.json(Object.keys(m).map(id=>info(id)));});
app.post('/api/servers',auth,(req,res)=>{try{const name=String(req.body?.name||'').trim();const id=String(req.body?.id||name.toLowerCase().replace(/[^a-z0-9_-]+/g,'-')).trim();if(!idSafe(id)||!name)throw new Error('Use a valid name/id');const meta=readMeta();if(meta[id])throw new Error('Server already exists');fs.mkdirSync(path.join(ROOT,id),{recursive:true});fs.writeFileSync(path.join(ROOT,id,'index.js'),`console.log('Hello from ${name}!');\nsetInterval(()=>console.log('Server running at '+new Date().toISOString()),30000);\n`);meta[id]={name,entry:'index.js',maxMemory:512,createdAt:new Date().toISOString()};writeMeta(meta);res.json(info(id));}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/servers/:id/start',auth,(req,res)=>{try{start(req.params.id);res.json(info(req.params.id));}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/servers/:id/stop',auth,(req,res)=>{try{stop(req.params.id);res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/servers/:id/restart',auth,(req,res)=>{try{stop(req.params.id);setTimeout(()=>{try{start(req.params.id);}catch(e){addLog(req.params.id,'[Panel] '+e.message);}},1200);res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.delete('/api/servers/:id',auth,(req,res)=>{try{const id=req.params.id;stop(id);const m=readMeta();if(!m[id])throw new Error('Not found');delete m[id];writeMeta(m);fs.rmSync(path.join(ROOT,id),{recursive:true,force:true});logs.delete(id);res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.get('/api/servers/:id/files',auth,(req,res)=>{try{const dir=path.join(ROOT,req.params.id);const rel=String(req.query.path||'');const p=safePath(dir,rel);const items=fs.readdirSync(p,{withFileTypes:true}).map(x=>{const full=path.join(p,x.name);return{name:x.name,type:x.isDirectory()?'dir':'file',size:x.isFile()?fs.statSync(full).size:0};});res.json({path:rel,items});}catch(e){res.status(400).json({error:e.message});}});
app.get('/api/servers/:id/file',auth,(req,res)=>{try{const p=safePath(path.join(ROOT,req.params.id),String(req.query.path||''));res.type('text/plain').send(fs.readFileSync(p,'utf8'));}catch(e){res.status(400).json({error:e.message});}});
app.put('/api/servers/:id/file',auth,(req,res)=>{try{const p=safePath(path.join(ROOT,req.params.id),String(req.query.path||''));fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,String(req.body?.content||''));res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.delete('/api/servers/:id/file',auth,(req,res)=>{try{const p=safePath(path.join(ROOT,req.params.id),String(req.query.path||''));fs.rmSync(p,{recursive:true,force:true});res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
const upload=multer({dest:path.join(__dirname,'data','uploads'),limits:{fileSize:100*1024*1024}});fs.mkdirSync(path.join(__dirname,'data','uploads'),{recursive:true});
app.post('/api/servers/:id/upload',auth,upload.single('file'),(req,res)=>{try{if(!req.file)throw new Error('No file');const rel=String(req.body.path||'');const dir=safePath(path.join(ROOT,req.params.id),rel);fs.mkdirSync(dir,{recursive:true});fs.renameSync(req.file.path,path.join(dir,path.basename(req.file.originalname)));res.json({ok:true});}catch(e){if(req.file)try{fs.unlinkSync(req.file.path)}catch{}res.status(400).json({error:e.message});}});
app.post('/api/servers/:id/command',auth,(req,res)=>{try{const p=processes.get(req.params.id);if(!p?.child)throw new Error('Server is offline');p.child.stdin.write(String(req.body?.command||'')+'\n');res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.get('/api/servers/:id/logs',auth,(req,res)=>res.json({logs:logs.get(req.params.id)||[]}));
const wss=new WebSocketServer({server,path:'/ws'});wss.on('connection',(ws,req)=>{const u=new URL(req.url,'http://localhost');const id=u.searchParams.get('id'),t=u.searchParams.get('token');if(!sessions.has(t)||!readMeta()[id])return ws.close();let s=processes.get(id);if(!s){s={clients:new Set()};processes.set(id,s)}s.clients.add(ws);ws.send(JSON.stringify({type:'status',status:s.child&&!s.child.killed?'online':'offline',logs:logs.get(id)||[]}));ws.on('close',()=>s.clients.delete(ws));});
server.listen(PORT,HOST,()=>console.log(`Node Anime Host Panel running on http://${HOST}:${PORT}`));
